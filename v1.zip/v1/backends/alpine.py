import shutil

from core import run_command


class AlpineBackend:

    name = "apk"

    def available(self):
        return shutil.which(
            "apk"
        ) is not None

    def find_kernel_package(self, release):
        paths = [
            f"/boot/vmlinuz-{release}",
            f"/lib/modules/{release}/vmlinuz",
        ]

        for path in paths:

            code, out, _ = run_command([
                "apk",
                "info",
                "--who-owns",
                path,
            ])

            if code != 0:
                continue

            line = out.strip()

            if ":" not in line:
                continue

            package = line.split(
                ":",
                1,
            )[0].strip()

            if not package:
                continue

            return {
                "name": package,
                "version": None,
            }

        return None

    def verify_package(self, package):
        code, out, err = run_command([
            "apk",
            "audit",
            package["name"],
        ])

        output = (
            out + err
        ).strip()

        if code == 0 and not output:
            return {
                "status": "ok",
                "files": [],
                "output": "",
            }

        return {
            "status": "corrupted",
            "files":
                output.splitlines(),
            "output": output,
        }

    def repair_info(self, package):
        code, out, err = run_command([
            "apk",
            "policy",
            package["name"],
        ])

        if code != 0:
            return None

        return {
            "available": True,
            "output":
                (out + err).strip(),
        }

    def repair(self, package):
        code, out, err = run_command([
            "apk",
            "fix",
            package["name"],
        ])

        return {
            "success": code == 0,
            "output":
                (out + err).strip(),
        }
