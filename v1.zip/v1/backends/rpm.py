import shutil

from core import run_command


class RpmBackend:

    name = "rpm/dnf/yum"

    def available(self):
        return (
            shutil.which("rpm") is not None
            and (
                shutil.which("dnf") is not None
                or shutil.which("yum") is not None
            )
        )

    def get_manager(self):
        if shutil.which("dnf"):
            return "dnf"

        if shutil.which("yum"):
            return "yum"

        return None

    def find_kernel_package(self, release):
        paths = [
            f"/boot/vmlinuz-{release}",
            f"/lib/modules/{release}/vmlinuz",
            f"/usr/lib/modules/{release}/vmlinuz",
        ]

        for path in paths:

            code, out, _ = run_command([
                "rpm",
                "-qf",
                path,
            ])

            if code != 0:
                continue

            package = out.strip()

            if not package:
                continue

            code, version, _ = run_command([
                "rpm",
                "-q",
                "--qf",
                "%{VERSION}-%{RELEASE}.%{ARCH}",
                package,
            ])

            if code != 0:
                continue

            return {
                "name": package,
                "version": version.strip(),
            }

        return None

    def verify_package(self, package):
        code, out, err = run_command([
            "rpm",
            "-V",
            package["name"],
        ])

        output = (
            out + err
        ).strip()

        if code == 0 and not output:
            return {
                "status": "ok",
                "files": [],
                "output": "",
            }

        files = []

        for line in output.splitlines():

            line = line.strip()

            if not line:
                continue

            parts = line.split(
                None,
                1,
            )

            if len(parts) == 2:
                files.append(parts[1])
            else:
                files.append(line)

        return {
            "status": "corrupted",
            "files": files,
            "output": output,
        }

    def repair_info(self, package):
        manager = self.get_manager()

        if not manager:
            return None

        code, out, err = run_command([
            manager,
            "reinstall",
            package["name"],
            "--assumeno",
        ])

        return {
            "manager": manager,
            "available": code == 0,
            "output":
                (out + err).strip(),
        }

    def repair(self, package):
        manager = self.get_manager()

        if not manager:
            return {
                "success": False,
                "output":
                    "DNF/YUM introuvable.",
            }

        code, out, err = run_command([
            manager,
            "reinstall",
            "-y",
            package["name"],
        ])

        return {
            "success": code == 0,
            "output":
                (out + err).strip(),
        }
