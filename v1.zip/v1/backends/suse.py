import shutil

from core import run_command


class SuseBackend:

    name = "rpm/zypper"

    def available(self):
        return (
            shutil.which("rpm") is not None
            and shutil.which("zypper") is not None
        )

    def find_kernel_package(self, release):
        paths = [
            f"/boot/vmlinuz-{release}",
            f"/lib/modules/{release}/vmlinuz",
            f"/usr/lib/modules/{release}/vmlinuz",
        ]

        for path in paths:

            code, out, _ = run_command([
                "rpm",
                "-qf",
                path,
            ])

            if code != 0:
                continue

            package = out.strip()

            if not package:
                continue

            code, version, _ = run_command([
                "rpm",
                "-q",
                "--qf",
                "%{VERSION}-%{RELEASE}.%{ARCH}",
                package,
            ])

            if code != 0:
                continue

            return {
                "name": package,
                "version": version.strip(),
            }

        return None

    def verify_package(self, package):
        code, out, err = run_command([
            "rpm",
            "-V",
            package["name"],
        ])

        output = (
            out + err
        ).strip()

        if code == 0 and not output:
            return {
                "status": "ok",
                "files": [],
                "output": "",
            }

        return {
            "status": "corrupted",
            "files":
                output.splitlines(),
            "output": output,
        }

    def repair_info(self, package):
        code, out, err = run_command([
            "zypper",
            "--non-interactive",
            "info",
            package["name"],
        ])

        if code != 0:
            return None

        return {
            "available": True,
            "output":
                (out + err).strip(),
        }

    def repair(self, package):
        code, out, err = run_command([
            "zypper",
            "--non-interactive",
            "--no-recommends",
            "install",
            "--force-resolution",
            package["name"],
        ])

        return {
            "success": code == 0,
            "output":
                (out + err).strip(),
        }
