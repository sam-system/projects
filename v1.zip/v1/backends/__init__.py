from .debian import DebianBackend
from .rpm import RpmBackend
from .suse import SuseBackend
from .pacman import PacmanBackend
from .alpine import AlpineBackend


def detect_backend():
    """
    Détecte le backend disponible.

    L'ordre est important pour éviter
    qu'un backend générique masque un backend
    plus spécifique.
    """

    backends = [
        DebianBackend(),
        SuseBackend(),
        RpmBackend(),
        PacmanBackend(),
        AlpineBackend(),
    ]

    for backend in backends:
        if backend.available():
            return backend

    return None
