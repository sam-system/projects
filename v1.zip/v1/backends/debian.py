import shutil

from core import run_command


class DebianBackend:

    name = "dpkg/apt"

    def available(self):
        return (
            shutil.which("dpkg") is not None
            and shutil.which("apt-get") is not None
        )

    def find_kernel_package(self, release):
        paths = [
            f"/boot/vmlinuz-{release}",
            f"/lib/modules/{release}/vmlinuz",
            f"/usr/lib/modules/{release}/vmlinuz",
        ]

        for path in paths:

            code, out, _ = run_command([
                "dpkg",
                "-S",
                path,
            ])

            if code != 0:
                continue

            line = out.strip()

            if ":" not in line:
                continue

            package = line.split(
                ":",
                1,
            )[0]

            code, version, _ = run_command([
                "dpkg-query",
                "-W",
                "-f=${Version}",
                package,
            ])

            if code != 0:
                continue

            return {
                "name": package,
                "version": version.strip(),
            }

        return None

    def verify_package(self, package):
        code, out, err = run_command([
            "dpkg",
            "--verify",
            package["name"],
        ])

        output = (
            out + err
        ).strip()

        if code == 0 and not output:
            return {
                "status": "ok",
                "files": [],
                "output": "",
            }

        return {
            "status": "corrupted",
            "files": [
                line.strip()
                for line in output.splitlines()
                if line.strip()
            ],
            "output": output,
        }

    def repair_info(self, package):
        code, out, _ = run_command([
            "apt-cache",
            "policy",
            package["name"],
        ])

        if code != 0:
            return None

        installed = None
        candidate = None

        for line in out.splitlines():

            line = line.strip()

            if line.startswith(
                "Installed:"
            ):
                installed = (
                    line
                    .split(":", 1)[1]
                    .strip()
                )

            elif line.startswith(
                "Candidate:"
            ):
                candidate = (
                    line
                    .split(":", 1)[1]
                    .strip()
                )

        if not installed or not candidate:
            return None

        return {
            "installed": installed,
            "candidate": candidate,
            "same_version":
                installed == candidate,
        }

    def repair(self, package):
        version = package["version"]

        command = [
            "apt-get",
            "install",
            "--reinstall",
            "-y",
            f"{package['name']}={version}",
        ]

        code, out, err = run_command(
            command
        )

        return {
            "success": code == 0,
            "output":
                (out + err).strip(),
        }
