import shutil

from core import run_command


class PacmanBackend:

    name = "pacman"

    def available(self):
        return shutil.which(
            "pacman"
        ) is not None

    def find_kernel_package(self, release):
        paths = [
            f"/boot/vmlinuz-{release}",
            f"/usr/lib/modules/{release}/vmlinuz",
        ]

        for path in paths:

            code, out, _ = run_command([
                "pacman",
                "-Qo",
                path,
            ])

            if code != 0:
                continue

            parts = out.strip().split()

            if "by" not in parts:
                continue

            try:
                package = parts[
                    parts.index("by") + 1
                ]

            except IndexError:
                continue

            code, version, _ = run_command([
                "pacman",
                "-Q",
                package,
            ])

            if code != 0:
                continue

            version_parts = (
                version.strip().split()
            )

            if len(version_parts) < 2:
                continue

            return {
                "name": package,
                "version":
                    version_parts[1],
            }

        return None

    def verify_package(self, package):
        code, out, err = run_command([
            "pacman",
            "-Qkk",
            package["name"],
        ])

        output = (
            out + err
        ).strip()

        if code == 0:
            return {
                "status": "ok",
                "files": [],
                "output": output,
            }

        return {
            "status": "corrupted",
            "files":
                output.splitlines(),
            "output": output,
        }

    def repair_info(self, package):
        code, out, err = run_command([
            "pacman",
            "-Si",
            package["name"],
        ])

        if code != 0:
            return None

        candidate = None

        for line in out.splitlines():

            line = line.strip()

            if line.startswith(
                "Version"
            ):
                candidate = (
                    line
                    .split(":", 1)[1]
                    .strip()
                )
                break

        if not candidate:
            return None

        return {
            "candidate": candidate,
            "same_version":
                candidate ==
                package["version"],
        }

    def repair(self, package):
        code, out, err = run_command([
            "pacman",
            "-S",
            "--noconfirm",
            package["name"],
        ])

        return {
            "success": code == 0,
            "output":
                (out + err).strip(),
        }
