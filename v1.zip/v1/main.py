#!/usr/bin/env python3

import argparse
import platform

from core import (
    get_os_info,
    get_kernel_info,
    is_root,
    build_report,
)

from backends import detect_backend
from ai import AIAnalyzer


def print_header():
    print()
    print("=" * 60)
    print(" KernelCheck V2")
    print(" Production Safe Mode")
    print("=" * 60)
    print()


def ask_confirmation():
    answer = input(
        "Effectuer la réparation ? [y/N] : "
    ).strip().lower()

    return answer in {
        "y",
        "yes",
        "o",
        "oui",
    }


def run_ai(
    args,
    os_info,
    kernel,
    backend,
    package,
    verification,
    repair_info,
):
    print()
    print("[AI FALLBACK]")
    print()

    if not args.ai_url:
        print("[!] --ai-url est requis.")
        return 1

    if not args.ai_model:
        print("[!] --ai-model est requis.")
        return 1

    report = build_report(
        os_info,
        kernel,
        backend,
        package,
        verification,
        repair_info,
    )

    analyzer = AIAnalyzer(
        args.ai_url,
        args.ai_model,
    )

    result = analyzer.analyze(report)

    if result["status"] != "ok":
        print(
            f"[!] IA : "
            f"{result.get('reason', 'erreur')}"
        )
        return 1

    print()
    print(f"  Action    : {result['action']}")
    print(
        f"  Confiance : "
        f"{result['confidence']:.2f}"
    )
    print(
        f"  Analyse   : "
        f"{result['reason']}"
    )

    print()
    print(
        "[i] L'IA ne peut pas modifier "
        "directement le système."
    )

    return 1


def main():
    parser = argparse.ArgumentParser(
        description=(
            "KernelCheck - vérification et "
            "réparation conservatrice du kernel Linux."
        )
    )

    parser.add_argument(
        "--repair",
        action="store_true",
        help="Autorise les réparations.",
    )

    parser.add_argument(
        "--ai",
        action="store_true",
        help="Active le fallback IA.",
    )

    parser.add_argument(
        "--ai-url",
        help="URL d'une API compatible OpenAI.",
    )

    parser.add_argument(
        "--ai-model",
        help="Modèle IA à utiliser.",
    )

    args = parser.parse_args()

    print_header()

    # ======================================================
    # SYSTEM
    # ======================================================

    os_info = get_os_info()
    kernel = get_kernel_info()

    print("[SYSTEM]")

    print(
        f"  OS           : "
        f"{os_info.get('PRETTY_NAME', 'Unknown')}"
    )

    print(
        f"  Distribution : "
        f"{os_info.get('ID', 'unknown')}"
    )

    print(
        f"  Version      : "
        f"{os_info.get('VERSION_ID', 'unknown')}"
    )

    print(
        f"  Architecture : "
        f"{platform.machine()}"
    )

    print(
        f"  Kernel       : "
        f"{kernel['release'] or 'Unknown'}"
    )

    print()

    if not kernel["release"]:
        print(
            "[!] Impossible de déterminer "
            "le kernel actuel."
        )
        return 1

    # ======================================================
    # PACKAGE MANAGER
    # ======================================================

    backend = detect_backend()

    if backend is None:
        print(
            "[!] Aucun gestionnaire de paquets "
            "supporté n'a été détecté."
        )
        return 1

    print("[PACKAGE MANAGER]")
    print(f"  [+] {backend.name}")
    print()

    # ======================================================
    # KERNEL PACKAGE
    # ======================================================

    print("[KERNEL PACKAGE]")

    package = backend.find_kernel_package(
        kernel["release"]
    )

    if package is None:
        print(
            "  [!] Impossible d'identifier "
            "le package du kernel courant."
        )

        print(
            "  [i] Aucune modification effectuée."
        )

        return 1

    print(
        f"  [+] {package['name']}"
    )

    if package.get("version"):
        print(
            f"  Version : "
            f"{package['version']}"
        )

    print()

    # ======================================================
    # INTEGRITY
    # ======================================================

    print("[PACKAGE INTEGRITY]")

    verification = backend.verify_package(
        package
    )

    if verification["status"] == "ok":
        print("  [+] Intègre")
        print()
        print("=" * 60)
        print(" Scan terminé.")
        print("=" * 60)
        return 0

    print("  [!] CORRUPTION DETECTEE")

    if verification["files"]:
        for file in verification["files"]:
            print(f"      - {file}")

    print()

    # ======================================================
    # REPAIR INFORMATION
    # ======================================================

    repair_info = backend.repair_info(
        package
    )

    if repair_info is None:
        print(
            "[!] Impossible de déterminer "
            "une source de réparation sûre."
        )

        print(
            "[i] Aucune modification effectuée."
        )

        if args.ai:
            return run_ai(
                args,
                os_info,
                kernel,
                backend,
                package,
                verification,
                None,
            )

        return 1

    # ======================================================
    # READ-ONLY MODE
    # ======================================================

    if not args.repair:
        print(
            "[i] Mode lecture seule."
        )

        print(
            "    Utilisez --repair pour "
            "autoriser une réparation."
        )

        if args.ai:
            return run_ai(
                args,
                os_info,
                kernel,
                backend,
                package,
                verification,
                repair_info,
            )

        return 1

    # ======================================================
    # ROOT
    # ======================================================

    if not is_root():
        print(
            "[!] La réparation nécessite "
            "les privilèges root."
        )

        print(
            "[i] Relancez avec sudo/root."
        )

        return 1

    # ======================================================
    # CONFIRMATION
    # ======================================================

    print("[REPAIR]")

    print(
        f"  Package : "
        f"{package['name']}"
    )

    if package.get("version"):
        print(
            f"  Version : "
            f"{package['version']}"
        )

    print()
    print(
        "[!] Cette opération va modifier "
        "le système."
    )

    if not ask_confirmation():
        print()
        print(
            "[i] Réparation annulée."
        )
        return 0

    # ======================================================
    # REPAIR
    # ======================================================

    print()
    print(
        "[*] Réparation en cours..."
    )

    result = backend.repair(package)

    if not result["success"]:
        print(
            "[!] Échec de la réparation."
        )

        if result["output"]:
            print()
            print(result["output"])

        if args.ai:
            return run_ai(
                args,
                os_info,
                kernel,
                backend,
                package,
                verification,
                repair_info,
            )

        return 1

    print(
        "[+] Réparation terminée."
    )

    # ======================================================
    # RECHECK
    # ======================================================

    print()
    print(
        "[*] Nouvelle vérification..."
    )

    verification_after = (
        backend.verify_package(package)
    )

    if verification_after["status"] == "ok":
        print(
            "[+] Package maintenant intègre."
        )

        print()
        print("=" * 60)
        print(" Scan terminé.")
        print("=" * 60)

        return 0

    print(
        "[!] Le problème persiste."
    )

    print(
        "[i] Aucune nouvelle modification "
        "automatique effectuée."
    )

    if args.ai:
        return run_ai(
            args,
            os_info,
            kernel,
            backend,
            package,
            verification_after,
            repair_info,
        )

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
