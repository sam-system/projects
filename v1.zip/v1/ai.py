import json
import urllib.error
import urllib.request
from getpass import getpass


class AIAnalyzer:

    def __init__(
        self,
        base_url,
        model,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model

    def ask_key(self):
        return getpass(
            "Clé API : "
        )

    def analyze(self, report):
        print(
            "[AI] Une analyse IA est nécessaire."
        )

        api_key = self.ask_key()

        if not api_key:
            return {
                "status": "cancelled",
            }

        try:
            return self._request(
                api_key,
                report,
            )

        finally:
            # Supprime la référence locale.
            del api_key

    def _request(
        self,
        api_key,
        report,
    ):
        payload = {
            "model": self.model,

            "temperature": 0,

            "messages": [
                {
                    "role": "system",

                    "content": (
                        "Tu es un analyseur de sécurité "
                        "Linux pour un outil de production. "
                        "Analyse uniquement les données "
                        "fournies. "
                        "Ne fournis aucune commande shell, "
                        "aucune URL et aucune instruction "
                        "d'exécution. "
                        "Réponds exclusivement en JSON."
                    ),
                },

                {
                    "role": "user",

                    "content": (
                        "Analyse ce rapport :\n\n"
                        +
                        json.dumps(
                            report,
                            indent=2,
                            ensure_ascii=False,
                        )
                        +
                        "\n\n"
                        "Choisis une action parmi : "
                        "NO_ACTION, "
                        "RECHECK, "
                        "INVESTIGATE, "
                        "REINSTALL_PACKAGE."
                    ),
                },
            ],
        }

        data = json.dumps(
            payload
        ).encode()

        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=data,

            headers={
                "Content-Type":
                    "application/json",

                "Authorization":
                    f"Bearer {api_key}",
            },

            method="POST",
        )

        try:
            with urllib.request.urlopen(
                request,
                timeout=60,
            ) as response:

                raw = (
                    response
                    .read()
                    .decode()
                )

        except (
            urllib.error.URLError,
            urllib.error.HTTPError,
            TimeoutError,
        ) as error:

            return {
                "status": "error",
                "reason": str(error),
            }

        try:
            data = json.loads(raw)

            content = (
                data["choices"][0]
                ["message"]["content"]
            )

            result = json.loads(content)

        except (
            json.JSONDecodeError,
            KeyError,
            IndexError,
            TypeError,
        ):

            return {
                "status": "error",
                "reason":
                    "Réponse IA invalide.",
            }

        allowed = {
            "NO_ACTION",
            "RECHECK",
            "INVESTIGATE",
            "REINSTALL_PACKAGE",
        }

        if result.get("action") not in allowed:
            return {
                "status": "error",
                "reason":
                    "Action IA invalide.",
            }

        try:
            confidence = float(
                result.get(
                    "confidence",
                    0,
                )
            )

        except (
            TypeError,
            ValueError,
        ):
            confidence = 0.0

        confidence = max(
            0.0,
            min(
                1.0,
                confidence,
            ),
        )

        return {
            "status": "ok",

            "action":
                result["action"],

            "reason":
                str(
                    result.get(
                        "reason",
                        "",
                    )
                ),

            "confidence":
                confidence,
        }
