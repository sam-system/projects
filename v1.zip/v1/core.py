import os
import platform
import subprocess


def run_command(command):
    """
    Exécute une commande sans shell.
    Retourne :
        returncode, stdout, stderr
    """

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
        )

        return (
            result.returncode,
            result.stdout,
            result.stderr,
        )

    except OSError as error:
        return (
            -1,
            "",
            str(error),
        )


def read_file(path):
    try:
        with open(
            path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as file:
            return file.read().strip()

    except OSError:
        return None


def get_os_info():
    """
    Lit les informations de distribution
    depuis les fichiers standards Linux.
    """

    paths = [
        "/etc/os-release",
        "/usr/lib/os-release",
    ]

    for path in paths:
        content = read_file(path)

        if not content:
            continue

        data = {}

        for line in content.splitlines():
            line = line.strip()

            if (
                not line
                or line.startswith("#")
                or "=" not in line
            ):
                continue

            key, value = line.split(
                "=",
                1,
            )

            value = value.strip()

            if (
                len(value) >= 2
                and value[0] == value[-1]
                and value[0] in ("'", '"')
            ):
                value = value[1:-1]

            data[key] = value

        return data

    return {}


def get_kernel_info():
    """
    Récupère les informations du kernel
    directement depuis /proc.
    """

    return {
        "release": read_file(
            "/proc/sys/kernel/osrelease"
        ),

        "version": read_file(
            "/proc/sys/kernel/version"
        ),

        "proc_version": read_file(
            "/proc/version"
        ),

        "cmdline": read_file(
            "/proc/cmdline"
        ),
    }


def is_root():
    return os.geteuid() == 0


def build_report(
    os_info,
    kernel,
    backend,
    package,
    verification,
    repair_info=None,
):
    return {
        "system": {
            "distribution":
                os_info.get(
                    "PRETTY_NAME",
                    "Unknown",
                ),

            "distribution_id":
                os_info.get(
                    "ID",
                    "unknown",
                ),

            "version":
                os_info.get(
                    "VERSION_ID",
                    "unknown",
                ),

            "architecture":
                platform.machine(),

            "backend":
                backend.name,
        },

        "kernel": kernel,

        "package": package,

        "verification": verification,

        "repair_info": repair_info,
    }
